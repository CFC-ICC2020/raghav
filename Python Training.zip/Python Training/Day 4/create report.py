import openpyxl
import os
import sys
from openpyxl.styles.borders import Border, Side
from openpyxl.styles import Font
from openpyxl.styles import Alignment


with open("Box_jobs.txt", mode = 'r') as file:
    box_content = file.readlines()


def as_text(value):
    if value is None:
        return ""
    return str(value)

if False:
    pass
else:
    wb = openpyxl.Workbook()
    sheet = wb.active
    sheet.title = "RAIS Jobs Report"
    thin_border = Border(left=Side(style='thin'), 
                     right=Side(style='thin'), 
                     top=Side(style='thin'), 
                     bottom=Side(style='thin'))
    sheet.merge_cells(start_row=2, start_column=1, end_row=2, end_column=4)
    sheet.cell(row = 2, column = 4).border = thin_border
    col = 1
    sheet.cell(row = 2,column= 1).value = "Box Jobs status"
    sheet.cell(row=2, column= 1).alignment = Alignment(horizontal='center')
    sheet.cell(row=2, column= 1).font = Font(bold=True)
    sheet.cell(row=2, column= 1).border = thin_border
    sheet.cell(row = 1, column = 1).value = "Jobname"
    sheet.cell(row=1, column= 1).alignment = Alignment(horizontal='center')
    sheet.cell(row=1, column= 1).font = Font(bold=True)
    sheet.cell(row=1, column= 1).border = thin_border
    sheet.cell(row = 1, column = 2).value = "Last Start"
    sheet.cell(row=1, column= 2).alignment = Alignment(horizontal='center')
    sheet.cell(row=1, column= 2).font = Font(bold=True)
    sheet.cell(row=1, column= 2).border = thin_border
    sheet.cell(row = 1, column = 3).value = "Last End"
    sheet.cell(row=1, column= 3).alignment = Alignment(horizontal='center')
    sheet.cell(row=1, column= 3).font = Font(bold=True)
    sheet.cell(row=1, column= 3).border = thin_border
    sheet.cell(row = 1, column = 4).value = "State"
    sheet.cell(row=1, column= 4).alignment = Alignment(horizontal='center')
    sheet.cell(row=1, column= 4).font = Font(bold=True)
    sheet.cell(row=1, column= 4).border = thin_border
    
    row  = 3
    column = 1
    for i in box_content:
        if not i.strip().startswith('Job') and not i.strip().startswith('____') and not i.strip() == "" and not i.strip() == None:
            jobname = i[0:65].strip()
            last_start = i[65:86].strip()
            last_end = i[86:107].strip()
            state = i[107:110].strip()
            sheet.cell(row = row, column = column).value = jobname
            sheet.cell(row=row, column= column).border = thin_border
            sheet.cell(row = row, column = column+1).value = last_start
            sheet.cell(row=row, column= column+1).border = thin_border
            sheet.cell(row = row, column = column+2).value = last_end
            sheet.cell(row=row, column= column+2).border = thin_border
            sheet.cell(row = row, column = column+3).value = state
            sheet.cell(row=row, column= column+3).border = thin_border
            row = row+1
    for column_cells in sheet.columns:
         length = max(len(as_text(cell.value)) for cell in column_cells)
         length = (length * 1.25)
         sheet.column_dimensions[column_cells[0].column_letter].width = length
    wb.save(r"report.xlsx")



