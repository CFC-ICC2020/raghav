a = input()
print(a)
