import csv
data = [['S.No', 'Associate ID', 'Name'], ['1','797846','Raghav']]
with open(r"C:\Coned\academy_sample.csv", mode = 'a', newline='') as w_file:
    writer = csv.writer(w_file)
    writer.writerows(data)
